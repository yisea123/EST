#ifndef _FONT__H_
#define _FONT__H_

extern const unsigned char FontNumber[];
extern const unsigned char MenuChinese[];
extern const unsigned char MenuChinese1[];
extern const unsigned char MenuChinese2[];

#endif

