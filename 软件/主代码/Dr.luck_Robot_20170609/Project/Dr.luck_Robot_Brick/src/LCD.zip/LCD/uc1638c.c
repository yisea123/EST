
#include "uc1638c.h"

void LCD_UC1638C_GPIO_Init(void);
void Delay(u16 tt);
void initialize(void);
void iic_start(u8 cd)	;
void iic_send(unsigned char y);
void iic_stop(void);
void setWindowsProgame(void);

void set_uc1638c_Addr(u8 page,u8 column);


void LCD_UC1638C_Init(void)
{
	LCD_UC1638C_GPIO_Init();
	initialize();
}

void LCD_UC1638C_GPIO_Init(void)
{
	 //GPIO������ʼ��
	 GPIO_InitTypeDef GPIO_InitStructure;
	 //����GPIO��ʱ��  
	 RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);

	 GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_10;		//SCK��SDA��RST
	 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;                                                    
	 GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	 GPIO_Init(GPIOD, &GPIO_InitStructure); 
}


void initialize(void)
{
	Delay(1000);
	LCD_UC1638C_RST_1;
	Delay(400);
	LCD_UC1638C_RST_0;
	Delay(3200);
	LCD_UC1638C_RST_1;
	Delay(8000);
	
  //	unsigned char i;
	iic_start(0);			 //����ͷ
	iic_send(0xe1);	   //system reset
	iic_stop();				 //����β
	iic_start(1);
	iic_send(0xe2);		
	iic_stop();       
	Delay(200);
	
	iic_start(0);
	iic_send(0x04);		//column start		
	iic_stop();
	iic_start(1);
	iic_send(0x00);		//����SRAM�е�ַ
	iic_stop();       
				 
	iic_start(0);
	iic_send(0x2d);	  //internal booster	SET PUMP CONTROL
	iic_send(0x24);	  //tc
	iic_send(0xeb);		//1/12bias
	iic_stop();

	iic_start(0);
	iic_send(0x81);		 //pm set	SET VBIAS POTENTIOMETER
	iic_stop();
	iic_start(1);
	iic_send(115);  	//85=14.5V			��������
	iic_stop();

	iic_start(0);
	iic_send(0x40);		   //scroll line	���ù�����
	iic_send(0x50);
	iic_send(0x86);		   //com scan mode
	iic_send(0x89);
	iic_send(0xC2);
	iic_send(0xa3);		   //line rate
	iic_send(0x95);		   //display mode
	iic_stop();

	iic_start(0);
	iic_send(0xc8);		   //n-line 
	iic_stop();
	iic_start(1);
	iic_send(57);
	iic_stop();


	iic_start(0);
	iic_send(0xf1);			//com end
	iic_stop();
	iic_start(1);
	iic_send(127);
	iic_stop();

	iic_start(0);
	iic_send(0xf2);		   //partial display com start
	iic_stop();
	iic_start(1);
	iic_send(0);
	iic_stop();

	iic_start(0);
	iic_send(0xf3);			//partial display com end 
	iic_stop();
	iic_start(1);
	iic_send(127);
	iic_stop();

	iic_start(0);
	iic_send(0x85);			//partial display enable
	iic_stop();   

	iic_start(0);
	iic_send(0xc9);			//display enable
	iic_stop();
	iic_start(1);
	iic_send(0xad);			 //b/w dispay mode
	iic_stop();

}

void setWindowsProgame(void)     
{
	//���ô��������п�ʼ��ʾ
	iic_start(0);
	iic_send(0x04); //colum 		����SRAM��д�����е�ַΪ0x00
	iic_stop();
	iic_start(1);
	iic_send(0x00);
	iic_stop();

	iic_start(0);
	iic_send(0x60); //page 			����SRAM��д����ҳ��ַ�ӵ�0ҳ��ʼ
	iic_send(0x70);
	iic_stop();
	
//	//������ʾ��Χ
//	
//	iic_start(0);
//	iic_send(0xf4); //Set Window Programming Starting Column Address
//	iic_stop();
//	iic_start(1);
//	iic_send(0x00); //startx  ��0�п�ʼ����
//	iic_stop();

//	iic_start(0);
//	iic_send(0xf6); //Set Window Programming Ending Column Address 
//	iic_stop();
//	iic_start(1);
//	iic_send(239);//endx 			��239�н������ң�
//	iic_stop();
//	
//	iic_start(0);
//	iic_send(0xf5); //Set Window Programming Starting Page Address
//	iic_stop();
//	iic_start(1);
//	iic_send(0x00); //��0ҳ��ʼ���ϣ�
//	iic_stop();
//	
//	iic_start(0);
//	iic_send(0xf7); //Set Window Programming Ending Page Address
//	iic_stop();
//	iic_start(1);
//	iic_send(127);	//��127ҳ�������£�
//	iic_stop();
	
	iic_start(0);		//Enable Window Program ʹ�ܶ���Ļ�Ĳ���
	iic_send(0xf9);  
	iic_stop();
}



/*============================
  I2c start condition          
 SDA high->low while SCL=high 
     _________                 
  SCL         \_________       
     _______                  
  SDA       \___________      
============================*/

void iic_start(u8 cd)				//1send IIC start condition
{
	LCD_UC1638C_SDA_1;
	LCD_UC1638C_SCK_1;
	LCD_UC1638C_SDA_0;__NOP();
	LCD_UC1638C_SCK_0;__NOP();__NOP();__NOP();__NOP();
	
	LCD_UC1638C_SDA_0;LCD_UC1638C_SCK_1;LCD_UC1638C_SCK_0;
	LCD_UC1638C_SDA_1;LCD_UC1638C_SCK_1;LCD_UC1638C_SCK_0;
	LCD_UC1638C_SDA_1;LCD_UC1638C_SCK_1;LCD_UC1638C_SCK_0;
	LCD_UC1638C_SDA_1;LCD_UC1638C_SCK_1;LCD_UC1638C_SCK_0;			//����ͷ��0111B��
	
	LCD_UC1638C_SDA_1;LCD_UC1638C_SCK_1;LCD_UC1638C_SCK_0;
	LCD_UC1638C_SDA_0;LCD_UC1638C_SCK_1;LCD_UC1638C_SCK_0;			//�豸��ַ device address [1,0] 
	
	if(!cd)	LCD_UC1638C_SDA_0;			//contorl										//ģʽѡ��control��data,control����ѡ��ģʽ��data�����ڸ�ģʽ���շ�����
	else LCD_UC1638C_SDA_1;					//data
	LCD_UC1638C_SCK_1;LCD_UC1638C_SCK_0;
	LCD_UC1638C_SDA_0;LCD_UC1638C_SCK_1;LCD_UC1638C_SCK_0;		
	
	LCD_UC1638C_SCK_1;__NOP();__NOP();			//---signal A-----------//
	LCD_UC1638C_SCK_0;__NOP();__NOP();
	
}

//----------------------write_iic{cd=0(control);  cd=1(data)}---------------------//
void iic_send(unsigned char y)
{
	unsigned char i;
	for(i=0;i<8;i++)
	{
		if(y&0x80)
			LCD_UC1638C_SDA_1;
		else
		  LCD_UC1638C_SDA_0;
		LCD_UC1638C_SCK_1;
		LCD_UC1638C_SCK_0;
		y=y<<1;
	}  
  LCD_UC1638C_SCK_1;       //---signal A-----------//
  __NOP();
  __NOP();       
  LCD_UC1638C_SCK_0;
  __NOP();
  __NOP();

}

/*============================
  I2c stop condition          
  SDA low->high while SCL=high 
            _________                 
  SCL______/       
             _______                  
  SDA_______/      
============================*/

void iic_stop(void)
{
  LCD_UC1638C_SDA_0;__NOP(); __NOP();
  LCD_UC1638C_SCK_0;__NOP();__NOP();
  LCD_UC1638C_SCK_1;__NOP();__NOP();__NOP();__NOP();__NOP();
  LCD_UC1638C_SDA_1;__NOP();__NOP();__NOP();__NOP();
}


//������ʾλ��
void set_uc1638c_Addr(u8 page,u8 column) 
{
	iic_start(0);
	iic_send(0x04); //colum 		����SRAM��д�����е�ַ
	iic_stop();
	iic_start(1);
	iic_send(column);
	iic_stop();
	
	iic_start(0);
	iic_send((page%256)|0x60); //page   0-3λ			����SRAM��д����ҳ��ַ�ӵ�0ҳ��ʼ
	iic_send((page/256&0x03)|0x70);		//4��5λ
	iic_stop();
	
	iic_start(0);		//Enable Window Program ʹ�ܶ���Ļ�Ĳ���
	iic_send(0xf9);  
	iic_stop();

}

//��ʾ�ַ�
void Display_Char(u8 page,u8 column,u8 num)   //ҳ  ��  �ַ�
{
	u8 i,j;
	const u8 *dp = FontNumber;       //ָ������ȡģ�����ַ��ָ��
	
	num -= 0x20;
	
	dp = &FontNumber[num*16];
	
	for(j=0; j<2; j++)
	{
		set_uc1638c_Addr(32+page+j,60+column);
		for(i=0; i<8; i++)
		{
			iic_start(0);
			iic_send(0x01);
			iic_stop();
			iic_start(1);
			iic_send(*dp);
			iic_stop();
			
			dp++;
		}
	}
}

//����������ʾ��Display_Chinese(0,0,&MenuChinese[0*28]);
void Display_Chinese(u8 page,u8 column,const u8* dp)
{
	u8 i,j;
	
	for(j=0; j<2; j++)	//2
	{
		set_uc1638c_Addr(32+page+j,60+column);
		for(i=0; i<14; i++)	//14
		{
			iic_start(0);
			iic_send(0x01);
			iic_stop();
			iic_start(1);
			iic_send(*dp);
			iic_stop();
			dp++;
		}
	}
}

void Display_Hex2(u8 row,u8 col,u8 hexnum)   //�� ��  16������   //�޸��˲�����ȷ��ʾ16����
{
	 if((hexnum&0x0F) < 10)   Display_Char(row,col+8,(hexnum&0x0F)+48);
	 else                   Display_Char(row,col+8,(hexnum&0x0F)+55);
	
	 if((hexnum>>4) < 10)    Display_Char(row,col,(hexnum>>4)+48);
	 else                  Display_Char(row,col,(hexnum>>4)+55);
}

void Display_Dec2(u8 row,u8 col,u8 decnum)   //ʮ������  2λ
{
	Display_Char(row,col+8,decnum%10+48);
	Display_Char(row,col,decnum/10+48);
}

void Display_Dec4(u8 row,u8 col,u16 decnum)    //ʮ������  4λ
{
	Display_Char(row,col+24,decnum%10+48);
	decnum = decnum / 10;
	Display_Char(row,col+16,decnum%10+48);
	decnum = decnum / 10;
	Display_Char(row,col+8,decnum%10+48);
	decnum = decnum / 10;
	Display_Char(row,col,decnum%10+48);
}

void Display_Float(u8 row,u8 col,float decnum)    //ʮ���Ƹ�����  5λ,������  1000.1
{
	if(decnum<0)			//����
	{
		Display_Char(row,col,'-');
		decnum = -decnum;
		col += 8;
	}
	if((int)decnum/1000%10!=0)
	{
		Display_Char(row,col,(int)decnum/1000%10+48);
		Display_Char(row,col+8,(int)decnum/100%10+48);
		Display_Char(row,col+16,(int)decnum/10%10+48);
		Display_Char(row,col+24,(int)decnum%10+48);
		Display_Char(row,col+32,0x2E);
		Display_Char(row,col+40,(int)(decnum*10)%10+48);
	}
	else if((int)decnum/100%10!=0)
	{
		Display_Char(row,col,(int)decnum/100%10+48);
		Display_Char(row,col+8,(int)decnum/10%10+48);
		Display_Char(row,col+16,(int)decnum%10+48);
		Display_Char(row,col+24,0x2E);
		Display_Char(row,col+32,(int)(decnum*10)%10+48);
	}
	else if((int)decnum/10%10!=0)
	{
		Display_Char(row,col,(int)decnum/10%10+48);
		Display_Char(row,col+8,(int)decnum%10+48);
		Display_Char(row,col+16,0x2E);
		Display_Char(row,col+24,(int)(decnum*10)%10+48);
	}else{
		Display_Char(row,col,(int)decnum%10+48);
		Display_Char(row,col+8,0x2E);
		Display_Char(row,col+16,(int)(decnum*10)%10+48);
	}
}

void Display_String_Chs( u8 row, u8 col, u8 numChar, const u8* dp )   //��ʾһ��������
{
	u8 i;
	for( i=0; i<numChar; i++ )
	{
		Display_Chinese(row,col+i*14,dp);
		dp = dp + 28;
	}
}

void Display_String_Eng( u8 row, u8 col, char* str )     //��ʾһ��Ӣ��
{
	while(*str != '\0')
	{
		Display_Char(row,col,(*str));
		col = col + 8;
		str++;
	};
}

void Delay(u16 tt)
{
	u16 i,j;
	for(i=0;i<2000;i++)
		for(j=0;j<tt;j++);
}

//����
void display_white(u8 d1, u8 d2)
{
  unsigned char i;
  unsigned int j;
 
	for(i=0;i<16;i++)			 //����ÿ��128���㣬����һ��Ҫ16��8λ2����������ȫ������
  {
		set_uc1638c_Addr(32+i,60);
		for(j=0;j<180;j++)	  //����һ��120��
		{
		 iic_start(0);
		 iic_send(0x01);
		 iic_stop();
		 iic_start(1);
		 iic_send(d1);
		 iic_stop();

		 iic_start(0);
		 iic_send(0x01);
		 iic_stop();
		 iic_start(1);
		 iic_send(d2);
		 iic_stop();
		}
	}
	
}

void clearScreen(void)
{
	display_white(0x00, 0x00);
}

void display_test(u8 d1)
{
  unsigned char i;
  unsigned int j;
 
	for(i=0;i<8;i++)			 //����ÿ��128���㣬����һ��Ҫ16��8λ2����������ȫ������
  {
		set_uc1638c_Addr(32+i,60);
		for(j=0;j<90;j++)	  //����һ��120��
		{
		 iic_start(0);
		 iic_send(0x01);
		 iic_stop();
		 iic_start(1);
		 iic_send(d1);
		 iic_stop();

		}
	}
	
}

//row:0-16;
//col:0-180;
void Display_pic(u8 row, u8 col, u8 hight, u8 width, const u8 *pic )
{
  unsigned char i;
  unsigned int j;
  
	for(i=0;i<hight/8;i++)			 //16 �� 
  {
		for(j=0;j<width;j++)	//240 ��
		{
			set_uc1638c_Addr(32+row+i,60+col+j);
			iic_start(0);
			iic_send(0x01);
			iic_stop();
			iic_start(1);
			iic_send(*(pic++));
			iic_stop();     
	  }
	}
}

