
#ifndef __UI_PIC_H
#define __UI_PIC_H

extern const unsigned char ANI1X[];
extern const unsigned char PORT_3[];
extern const unsigned char PORT_4[];
extern const unsigned char PLAYLAST_TAB[];
extern const unsigned char FILE_TAB[]; 
extern const unsigned char APPS_TAB[];
extern const unsigned char SETTINGS_TAB[]; 	
extern const unsigned char MainMenuBottom[];

extern const unsigned char MotorCtlAD[];
extern const unsigned char MotorCtlBC[];

extern const unsigned char P0_top[] ;
extern const unsigned char P0_bot[] ;
extern const unsigned char P1[] ;
extern const unsigned char P2[] ;
extern const unsigned char P3[] ;
extern const unsigned char P4[] ;
extern const unsigned char PA[] ;
extern const unsigned char PB[] ;
extern const unsigned char PC[] ;
extern const unsigned char PD[] ;
extern const unsigned char View_Core[] ;
extern const unsigned char View_Vertical[] ;

extern const unsigned char color_amb[] ;
extern const unsigned char color_col[] ;
extern const unsigned char color_ref[] ;
extern const unsigned char gyro_a[] ;
extern const unsigned char gyro_rate[] ;
extern const unsigned char ir_bbut[] ;
extern const unsigned char ir_bpos[] ;
extern const unsigned char ir_prox[] ;
extern const unsigned char lrg_motor[] ;
extern const unsigned char lrg_motor_d[] ;
extern const unsigned char med_motor[] ;
extern const unsigned char med_motor_d[] ;
extern const unsigned char NXT_device[] ;
extern const unsigned char other[] ;
extern const unsigned char temp_c[] ;
extern const unsigned char temp_f[] ;
extern const unsigned char touch[] ;
extern const unsigned char us_prox[] ;
#endif
