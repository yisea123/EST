
#ifndef __UC1638C_H
#define __UC1638C_H

#include "stm32fxxx_it.h" 
#include "stdio.h"

#include "font.h"      //����


#define LCD_UC1638C_SCK_0 GPIO_ResetBits(GPIOD, GPIO_Pin_7)
#define LCD_UC1638C_SCK_1 GPIO_SetBits(GPIOD, GPIO_Pin_7)

#define LCD_UC1638C_SDA_0 GPIO_ResetBits(GPIOD, GPIO_Pin_8)
#define LCD_UC1638C_SDA_1 GPIO_SetBits(GPIOD, GPIO_Pin_8)

#define LCD_UC1638C_RST_0 GPIO_ResetBits(GPIOD, GPIO_Pin_10)
#define LCD_UC1638C_RST_1 GPIO_SetBits(GPIOD, GPIO_Pin_10)


void LCD_UC1638C_Init(void);
void clearScreen(void);
void display_white(u8 d1, u8 d2);
void Display_Char(u8 page,u8 column,u8 num);   //ҳ  ��  �ַ�
void Display_Hex2(u8 row,u8 col,u8 hexnum);
void Display_Dec2(u8 row,u8 col,u8 decnum);
void Display_Dec4(u8 row,u8 col,u16 decnum);
void Display_Float(u8 row,u8 col,float decnum) ;
void Display_Chinese(u8 page,u8 column,const u8* dp);
void Display_String_Eng( u8 row, u8 col, char* str );
void Display_String_Chs( u8 row, u8 col, u8 numChar, const u8* dp );

void Display_pic(u8 row, u8 col, u8 hight, u8 width, const u8 *pic );

void display_test(u8 d1);

#endif
